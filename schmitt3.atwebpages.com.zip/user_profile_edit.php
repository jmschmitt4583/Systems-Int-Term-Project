<?php

  /*
  
  Check session to see if we are logged in
  
  */
  session_start();
  session_regenerate_id();
  $is_logged_in = false;
  $user_name = '';
  if(isset($_SESSION['username'])){
     $is_logged_in = true;
     $user_name = $_SESSION['username'];
  }
  
   $mysqli = new mysqli("fdb1030.awardspace.net","4252439_schmitt","Schmitt4583","4252439_schmitt");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
} 




$sql = "select age, email_address, phone_number from user where user_name = '$user_name'";


        
        
if ($result = $mysqli -> query($sql)) {

  $num_rows = $result -> num_rows;
  
  $row = $result -> fetch_row();
  
  $age = $row[0];
  $email_address = $row[1];
  $phone_number = $row[2];
  
  
}

?>


<!DOCTYPE html>
<html>


<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Edit User Profile</title>
    <center><img src="JG.png"></center>
    
   <script type="text/javascript">

       /*
       
       This javascript function validates the Registration Form.
       It checks to make sure all the form fields are not not blank
       and that the password and confirm password fields match.
       If any of these validation rules fail, an alert message is
       displayed to the user and false is returned which prevents the
       Form from being submitted to the database.
       
       */

       function validateForm() {
       
          var isValid = true;
          var validMessage = "The following errors have been found:\n";
          
         
          var age = document.forms["userProfileEditForm"]["age"].value;
          var emailAddress =  document.forms["userProfileEditForm"]["email_address"].value;
          var phoneNumber = document.forms["userProfileEditForm"]["phone_number"].value;
          var password= document.forms["userProfileEditForm"]["password"].value;
          var confirmPassword= document.forms["userProfileEditForm"]["confirm_password"].value;
         
          
          
          
          if (age == "") {
            validMessage += "\nAge must be filled out";
            isValid = false;
          } else if(isNaN(age) || age < 0){
            validMessage += "\nAge must be a number 0 or greater";
            isValid = false;
          
          }
          
          if (emailAddress == "") {
            validMessage += "\nEmail Address must be filled out";
            isValid = false;
          }
          
          if (phoneNumber == "") {
            validMessage += "\nPhone Number must be filled out";
            isValid = false;
          }
          
          if (password == "") {
            validMessage += "\nPassword must be filled out";
            isValid = false;
          }
          
          if (confirmPassword == "") {
            validMessage += "\nConfirm Password must be filled out";
            isValid = false;
          }
          
          if(password != "" && confirmPassword != "") {
          
             if(password != confirmPassword) {
          
                     validMessage += "\nPassword and Confirm Password must match";
                     isValid = false;
             }
          }
          
          if(!isValid)  {
          
              alert(validMessage);
          
          
          }
          
          return isValid;
          
          
        }

</script>
    
    
</head>




<body>

<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
  <?php if($is_logged_in) { ?>
         <a href="logout_processor.php">Logout</a>
         <a href="user_profile_edit.php">Edit Profile</a>
  <?php } ?>
  
  
</center>
</div>

<div class="main">
<div class="header">
  Edit User Profile
</div>
<center>
<form name="userProfileEditForm" action="user_profile_edit_processor.php" onsubmit="return validateForm()" method="post">
<br>
  
  
  <label><b>User Name</b></label>
  <br>
  <?php echo $user_name ?>

  <input type="hidden" name="user_name" placeholder="Enter Username" value='<?php echo $user_name ?>'>
  <br>
  <label><b>Age</b></label>
  <br>
  <input type="text" name="age" placeholder="Enter Age" value='<?php echo $age ?>'>
  <br>
  <label><b>Email Address</b></label>
  <br>
  <input type="text" name="email_address" placeholder="Enter Email Address" value='<?php echo $email_address ?>'>
  <br>
  <label><b>Phone Number</b></label>
  <br>
  <input type="text" name="phone_number" placeholder="Enter Phone Number" value='<?php echo $phone_number ?>'>
<br>
  <label><b>Password</b></label>
  <br>
  <input type="password" name="password" placeholder="Create Password">
<br>
  <label><b>Confirm Password</b></label>
  <br>
  <input type="password" name="confirm_password" placeholder="Confirm Password">
<br>
  <button type="submit" class="btn2">Update Profile</button>
<br>
</form>
</center>
</div>


</body>
</html>