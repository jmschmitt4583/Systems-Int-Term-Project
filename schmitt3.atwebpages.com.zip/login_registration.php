<?php

  /*
  
  Check session to see if we are logged in
  
  */
  session_start();
  session_regenerate_id();
  $is_logged_in = false;
  if(isset($_SESSION['username'])){
     $is_logged_in = true;
  }

?>

<!DOCTYPE html>
<html>


<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Login</title>
    <center><img src="JG.png"></center>
    
    <script type="text/javascript">

       /*
       
       This javascript function validates the Registration Form.
       It checks to make sure all the form fields are not not blank
       and that the password and confirm password fields match.
       If any of these validation rules fail, an alert message is
       displayed to the user and false is returned which prevents the
       Form from being submitted to the database.
       
       */

       function validateForm() {
       
          var isValid = true;
          var validMessage = "The following errors have been found:\n";
          
          var userName = document.forms["loginForm"]["user_name"].value;
          var password= document.forms["loginForm"]["password"].value;
          
         
          
          if (userName == "") {
            validMessage += "\nUsername must be filled out";
            isValid = false;
          }
          
          
          
          if (password == "") {
            validMessage += "\nPassword must be filled out";
            isValid = false;
          }
          
          
          
          
          if(!isValid)  {
          
              alert(validMessage);
          
          
          }
          
          return isValid;
          
          
        }

</script>
    
    
</head>




<body>

<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
  <?php if($is_logged_in) { ?>
         <a href="logout_processor.php">Logout</a>
         <a href="user_profile_edit.php">Edit Profile</a>
  <?php } ?>
  
  
</center>
</div>



<div class="main">
<div class="header">
  Login
</div>
<center>
<form action="login_processor.php" name="loginForm" onsubmit="return validateForm()"  method="post">
<br>
  <label><b>Username</b></label>
  <br>
  <input type="text" name="user_name" placeholder="Enter Username">
<br>
  <label><b>Password</b></label>
  <br>
  <input type="password" name="password"  placeholder="Enter Password">
<br>
  <button type="submit" class="btn">Login</button>
<br>
</form>
<br>
    <a href="register.php">Create an Account </a>
</center>
</div>


</body>
</html>