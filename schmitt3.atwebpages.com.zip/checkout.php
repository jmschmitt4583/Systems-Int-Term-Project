<?php

  /*
  
  Check session to see if we are logged in
  
  */
  session_start();
  session_regenerate_id();
  $is_logged_in = false;
  if(isset($_SESSION['username'])){
     $is_logged_in = true;
  }

?>

<!DOCTYPE html>
<html>


<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Checkout</title>
  <center><img src="JG.png"></center>
</head>




<body>

<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
  <?php if($is_logged_in) { ?>
         <a href="logout_processor.php">Logout</a>
         <a href="user_profile_edit.php">Edit Profile</a>
  <?php } ?>
  
</center>
</div>

<div class="main">
<div class="header">
  Check Out
</div>
<center>
<br>
  <label><b>Full Name</b></label>
  <br>
  <input type="text" placeholder="Enter Full Name">
<br>
  <label><b>Card Information</b></label>
  <br>
  <input type="text" placeholder="Card Information">
 <br>
  <label><b>Address</b></label>
  <br>
  <input type="text" placeholder="Enter Address">
  <br>
    <button type="button" class="btn">Check Out</button>
</center>
</div>


</body>
</html>