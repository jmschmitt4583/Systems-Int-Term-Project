<!DOCTYPE html>
<html>

<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Update Failure</title>
  <center><img src="JG.png"></center>
</head>



<body>


<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
</center>
</div>




<div class="main" >

<div class="header" >
  Profile Update Failure
</div>
  <center> 
  Something went wrong.
  <br>
  
 <a href="user_profile_edit.php">Please reattempt to update here </a>
 <br>
</center>
</div>

</body>
</html>