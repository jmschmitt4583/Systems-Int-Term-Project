<?php

  /*
  
  Check session to see if we are logged in
  
  */
  session_start();
  session_regenerate_id();
  $is_logged_in = false;
  if(isset($_SESSION['username'])){
     $is_logged_in = true;
  }

?>

<!DOCTYPE html>
<html>

<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Home</title>
  <center><img src="JG.png"></center>
</head>



<body>


<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
  <?php if($is_logged_in) { ?>
         <a href="logout_processor.php">Logout</a>
         <a href="user_profile_edit.php">Edit Profile</a>
  <?php } ?>
         
 
  

  
</center>
</div>




<div class="main" >

<div class="header" >
  Home
</div>
  <center> 
  Welcome to our Website! Thank you for choosing Julia's Grocery Store.
</center>
</div>

<div>
  <br>
  <img src="Popular.png">
  <br>
  <p>
  <img src="Apples.png">
  &nbsp; &nbsp; &nbsp;
  <img src="Corn.png">
  &nbsp; &nbsp; &nbsp;
  <img src="Grapes.png">
  </p>
  </div>




</body>
</html>