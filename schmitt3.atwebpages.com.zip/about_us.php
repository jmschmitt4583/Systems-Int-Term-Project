<?php

  /*
  
  Check session to see if we are logged in
  
  */
  session_start();
  session_regenerate_id();
  $is_logged_in = false;
  if(isset($_SESSION['username'])){
     $is_logged_in = true;
  }

?>

<!DOCTYPE html>
<html>

<center>
<head>
  <link rel="stylesheet" href="style.css">
 <title>Julia's Grocery Store - About Us</title>
 <center><img src="JG.png"></center>
</head>




<body>

<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
  <?php if($is_logged_in) { ?>
         <a href="logout_processor.php">Logout</a>
         <a href="user_profile_edit.php">Edit Profile</a>
  <?php } ?>
         
</center>
</div>



<div class="main">
<div class="header">
  About Us
</div>
  <center>
  Julia's Grocery store is a small business run by the owner Julia Schmitt. This store opened in 1/1/22 with the goal of providing the best quality produce in the Ft Myers area.
  <br>
  We welcome all guests to stop by, check out our products page and have produce shipped to your or stop by in store today!
  <br>
  <br>
  <b>Business Hours</b>
  <br>
  Monday - Thursday:  8AM-10PM
  <br>
  Friday - Saturday:  8AM-11PM
  <br>
  Sunday:  8AM-9PM
  <br>
  <br>
  Contact us at Julia.Grocery.Store@Gmail.com
  </center>
</div>

</body>
</html>