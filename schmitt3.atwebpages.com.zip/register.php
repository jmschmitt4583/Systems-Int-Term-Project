<!DOCTYPE html>
<html>


<center>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Julia's Grocery Store - Registration</title>
    <center><img src="JG.png"></center>
    
   <script type="text/javascript">

       /*
       
       This javascript function validates the Registration Form.
       It checks to make sure all the form fields are not not blank
       and that the password and confirm password fields match.
       If any of these validation rules fail, an alert message is
       displayed to the user and false is returned which prevents the
       Form from being submitted to the database.
       
       */

       function validateForm() {
       
          var isValid = true;
          var validMessage = "The following errors have been found:\n";
          
          var userName = document.forms["registrationForm"]["user_name"].value;
          var age = document.forms["registrationForm"]["age"].value;
          var emailAddress =  document.forms["registrationForm"]["email_address"].value;
          var phoneNumber = document.forms["registrationForm"]["phone_number"].value;
          var password= document.forms["registrationForm"]["password"].value;
          var confirmPassword= document.forms["registrationForm"]["confirm_password"].value;
         
          
          if (userName == "") {
            validMessage += "\nUsername must be filled out";
            isValid = false;
          }
          
          if (age == "") {
            validMessage += "\nAge must be filled out";
            isValid = false;
          } else if(isNaN(age) || age < 0){
            validMessage += "\nAge must be a number 0 or greater";
            isValid = false;
          
          }
          
          if (emailAddress == "") {
            validMessage += "\nEmail Address must be filled out";
            isValid = false;
          }
          
          if (phoneNumber == "") {
            validMessage += "\nPhone Number must be filled out";
            isValid = false;
          }
          
          if (password == "") {
            validMessage += "\nPassword must be filled out";
            isValid = false;
          }
          
          if (confirmPassword == "") {
            validMessage += "\nConfirm Password must be filled out";
            isValid = false;
          }
          
          if(password != "" && confirmPassword != "") {
          
             if(password != confirmPassword) {
          
                     validMessage += "\nPassword and Confirm Password must match";
                     isValid = false;
             }
          }
          
          if(!isValid)  {
          
              alert(validMessage);
          
          
          }
          
          return isValid;
          
          
        }

</script>
    
    
</head>




<body>

<div class="navigationbar">
<center>
  <a href="index.php">Home</a>
  <a href="login_registration.php">Login </a>
  <a href="products_services.php">Products</a>
  <a href="checkout.php">Checkout</a>
  <a href="about_us.php">About Us</a>
</center>
</div>

<div class="main">
<div class="header">
  Registration
</div>
<center>
<form name="registrationForm" action="register_processor.php" onsubmit="return validateForm()" method="post">
<br>
  <label><b>User Name</b></label>
  <br>
  <input type="text" name="user_name" placeholder="Enter Username">
  <br>
  <label><b>Age</b></label>
  <br>
  <input type="text" name="age" placeholder="Enter Age">
  <br>
  <label><b>Email Address</b></label>
  <br>
  <input type="text" name="email_address" placeholder="Enter Email Address">
  <br>
  <label><b>Phone Number</b></label>
  <br>
  <input type="text" name="phone_number" placeholder="Enter Phone Number">
<br>
  <label><b>Password</b></label>
  <br>
  <input type="password" name="password" placeholder="Create Password">
<br>
  <label><b>Confirm Password</b></label>
  <br>
  <input type="password" name="confirm_password" placeholder="Confirm Password">
<br>
  <button type="submit" class="btn2">Register</button>
<br>
</form>
</center>
</div>


</body>
</html>