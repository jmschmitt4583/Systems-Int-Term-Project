<?php

/*

The session is created here

*/

session_start();

$mysqli = new mysqli("fdb1030.awardspace.net","4252439_schmitt","Schmitt4583","4252439_schmitt");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
} 




$user_name = $mysqli -> real_escape_string($_POST['user_name']);
$password = $mysqli -> real_escape_string($_POST['password']);


$sql = "select 1 from user where user_name = '$user_name' and password = '$password'";


        
        
if ($result = $mysqli -> query($sql)) {

  $num_rows = $result -> num_rows;

  
  if($num_rows > 0) {
     
       
       /*
       
       If the user is authenticated, we add the user name to the session so we can check
       for it later to see if the user is logged in  and whow they are
       
       */
       
       $_SESSION['username'] = $user_name;
       
       header("Location: login_success.php");
  } else {
  
        header("Location: login_failure.php");
      
  }
  
  // Free result set
  $result -> free_result();
}

$mysqli -> close();


?> 