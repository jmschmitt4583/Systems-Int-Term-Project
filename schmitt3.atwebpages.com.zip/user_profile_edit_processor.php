<?php




$mysqli = new mysqli("fdb1030.awardspace.net","4252439_schmitt","Schmitt4583","4252439_schmitt");

// Check connection
if ($mysqli -> connect_errno) {
  //echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
 // header("Location: registration_failure.html");
  //exit();
} 





$user_name = $mysqli -> real_escape_string($_POST['user_name']);
$password = $mysqli -> real_escape_string($_POST['password']);
$phone_number = $mysqli -> real_escape_string($_POST['phone_number']);
$age = $mysqli -> real_escape_string($_POST['age']);
$email_address = $mysqli -> real_escape_string($_POST['email_address']);

if($user_name != '' && $password != '' && $phone_number != '' &&  $age  != '' && $email_address != '') {



        $sql = "update user set password = '$password', phone_number = '$phone_number', age = '$age', 
            email_address = '$email_address' where user_name = '$user_name'";
               
                
                
        if (!$mysqli -> query($sql)) {
          
             header("Location: user_profile_edit_failure.php");
             exit();
          
          
        } else {
        
              header("Location: user_profile_edit_success.php");
              exit();
        
        }
 }

$mysqli -> close();


?>