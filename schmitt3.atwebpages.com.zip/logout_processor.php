<?php

/*

When this script is called from the Logout Url on the navbar, the session is destroyed
The username is no longer in the session and and session is destroyed.
We can check for the session and username varibale in the navbar code to know if the user
is logged in

*/

session_start();
unset($_SESSION['username']);
session_destroy();
header("Location: logout_success.php");


?>